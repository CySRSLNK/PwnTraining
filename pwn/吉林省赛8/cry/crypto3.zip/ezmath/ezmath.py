from Crypto.PublicKey import RSA
from Crypto.Util.number import *
import base64
import sympy
from secret import flag

flag = b'flag{xxxxxxxxxx}'

m = bytes_to_long(flag)
p = getPrime(512)
q = sympy.nextprime(p ^ ((1 << 512) - 1))
n = p * q
c = pow(m,e,n)

"""
n,e,c in those two files.  Find a way to get them.
"""
